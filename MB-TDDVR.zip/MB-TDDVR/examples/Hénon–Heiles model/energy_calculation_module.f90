! ============================================================================
! ENERGY CALCULATION MODULE - HENON-HEILES VERSION
! Computes total energy, kinetic energy, potential energy, and energy components
! Compatible with Henon-Heiles TDDVR simulations
! Based on: J. Chem. Phys. 117, 10499 (2002)
! ============================================================================

module energy_calculation_module
  use, intrinsic :: iso_fortran_env, only: real64, int32
  implicit none
  
  private
  
  ! Public types and procedures
  public :: energy_calculator, dp, ip
  public :: create_energy_calculator
  public :: set_henon_heiles_lambda, get_henon_heiles_lambda
  
  ! Kind parameters
  integer, parameter :: dp = real64
  integer, parameter :: ip = int32
  
  ! Constants (reduced units: ℏ = 1, m = 1, ω = 1)
  real(dp), parameter :: HBAR = 1.0_dp
  real(dp), parameter :: SMALL = 1.0e-12_dp
  
  ! Henon-Heiles anharmonicity parameter
  real(dp), private :: lambda_henon = 0.111803398875_dp  ! 1/√80
  
  ! Energy components type
  type :: energy_components
    real(dp) :: total_energy = 0.0_dp
    real(dp) :: kinetic_energy = 0.0_dp
    real(dp) :: potential_energy = 0.0_dp
    real(dp) :: classical_energy = 0.0_dp
    real(dp) :: quantum_energy = 0.0_dp
    real(dp) :: harmonic_energy = 0.0_dp
    real(dp) :: anharmonic_energy = 0.0_dp
    real(dp) :: coupling_energy = 0.0_dp
    real(dp) :: state_energies(1) = 0.0_dp
  end type energy_components
  
  ! Type for energy calculator
  type :: energy_calculator
    private
    logical :: enabled = .false.
    logical :: verbose = .true.
    logical :: parallel = .true.
    logical :: compute_components = .true.
    
    integer :: output_frequency = 10
    character(len=100) :: output_dir = "./energy_analysis/"
    
    type(energy_components), allocatable :: energy_history(:)
    real(dp), allocatable :: times(:)
    real(dp) :: energy_conservation_error = 0.0_dp
    real(dp) :: initial_total_energy = 0.0_dp
    
    integer :: unit_total = 500
    integer :: unit_components = 501
    integer :: unit_conservation = 502
    integer :: unit_state_energies = 503
    
    real(dp), allocatable :: grid_weights(:)
    
    integer(ip) :: nmode = 0
    integer(ip) :: nstate = 1
    integer(ip) :: nprod = 0
    
  contains
    procedure :: initialize => init_energy_calculator
    procedure :: compute_energies
    procedure :: compute_quantum_energy
    procedure :: compute_potential_energy
    procedure :: compute_state_energies
    procedure :: check_energy_conservation
    procedure :: save_energy_data
    procedure :: save_energy_components
    procedure :: save_state_energies
    procedure :: finalize => cleanup_energy_calculator
    procedure :: is_enabled
    procedure :: enable
    procedure :: disable
    procedure :: set_output_frequency
    procedure :: get_energy_conservation_error
    procedure :: print_energy_summary
    procedure :: setup_grid_weights
    procedure :: compute_quantum_energy_henon
    ! Removed: procedure :: set_henon_heiles_lambda (not needed as type-bound)
  end type energy_calculator
  
  ! Constructor interface
  interface energy_calculator
    module procedure create_calculator_instance
  end interface

contains

  ! ============================================================================
  ! CONSTRUCTOR
  ! ============================================================================
  function create_calculator_instance(enabled, verbose, parallel, &
       compute_components, output_freq) result(calc)
    logical, intent(in), optional :: enabled, verbose, parallel
    logical, intent(in), optional :: compute_components
    integer, intent(in), optional :: output_freq
    type(energy_calculator) :: calc
    
    if (present(enabled)) calc%enabled = enabled
    if (present(verbose)) calc%verbose = verbose
    if (present(parallel)) calc%parallel = parallel
    if (present(compute_components)) calc%compute_components = compute_components
    if (present(output_freq)) calc%output_frequency = output_freq
    
    calc%nstate = 1
    
    if (calc%verbose .and. calc%enabled) then
      print '(a)', 'Energy calculator created (enabled) for HENON-HEILES'
      print '(a,i0)', '  Electronic states: ', calc%nstate
      print '(a,f8.4)', '  Lambda (anharmonicity): ', lambda_henon
      print '(a,l)', '  Compute detailed components: ', calc%compute_components
      print '(a,i0)', '  Output frequency: every ', calc%output_frequency, ' steps'
      if (calc%parallel) print '(a)', '  Parallel execution: enabled'
    end if
  end function create_calculator_instance

  ! Alias for the main program
  function create_energy_calculator(enabled, verbose, parallel, &
       compute_components, output_freq) result(calc)
    logical, intent(in), optional :: enabled, verbose, parallel
    logical, intent(in), optional :: compute_components
    integer, intent(in), optional :: output_freq
    type(energy_calculator) :: calc
    
    calc = create_calculator_instance(enabled, verbose, parallel, &
         compute_components, output_freq)
  end function create_energy_calculator

  ! ============================================================================
  ! SET/GET LAMBDA (Module-level procedures)
  ! ============================================================================
  subroutine set_henon_heiles_lambda(lambda_in)
    real(dp), intent(in) :: lambda_in
    lambda_henon = lambda_in
    if (lambda_henon /= 0.111803398875_dp) then
      print '(a,es12.4)', 'Henon-Heiles lambda set to: ', lambda_henon
    end if
  end subroutine set_henon_heiles_lambda
  
  function get_henon_heiles_lambda() result(lambda_out)
    real(dp) :: lambda_out
    lambda_out = lambda_henon
  end function get_henon_heiles_lambda

  ! ============================================================================
  ! INITIALIZE ENERGY CALCULATOR
  ! ============================================================================
  subroutine init_energy_calculator(this, tstep, tint)
    class(energy_calculator), intent(inout) :: this
    integer(ip), intent(in) :: tstep
    real(dp), intent(in) :: tint
    
    integer :: ios
    character(len=200) :: dir_command
    integer :: nsteps_to_store
    
    if (.not. this%enabled) return
    
    if (this%verbose) then
      print '(a)', 'Initializing energy calculator for HENON-HEILES...'
      print '(a,i0)', '  Total time steps: ', tstep
      print '(a,f8.4,a)', '  Time step: ', tint, ' (reduced units)'
      print '(a,i0)', '  Dimensionality (f): ', this%nmode
      print '(a,f8.4)', '  Lambda: ', lambda_henon
    end if
    
    nsteps_to_store = tstep / this%output_frequency + 1
    
    allocate(this%energy_history(nsteps_to_store))
    allocate(this%times(nsteps_to_store))
    
    this%times = 0.0_dp
    this%energy_conservation_error = 0.0_dp
    this%initial_total_energy = 0.0_dp
    
    dir_command = 'mkdir -p ' // trim(this%output_dir)
    call system(dir_command)
    
    this%unit_total = 500
    open(unit=this%unit_total, &
         file=trim(this%output_dir)//'total_energy.dat', &
         status='replace', iostat=ios)
    if (ios /= 0) then
      print *, 'Error opening total_energy.dat'
      this%enabled = .false.
      return
    end if
    
    write(this%unit_total, '(a)') '# Total Energy vs Time for HENON-HEILES'
    write(this%unit_total, '(a)') '# Time, Total_Energy, Kinetic_Energy, Potential_Energy'
    
    if (this%compute_components) then
      this%unit_components = 501
      open(unit=this%unit_components, &
           file=trim(this%output_dir)//'energy_components.dat', &
           status='replace', iostat=ios)
      if (ios == 0) then
        write(this%unit_components, '(a)') '# Energy Components vs Time for HENON-HEILES'
        write(this%unit_components, '(a)') '# Time, Harmonic_E, Anharmonic_E, Classical_E, Quantum_E'
      end if
    end if
    
    this%unit_conservation = 502
    open(unit=this%unit_conservation, &
         file=trim(this%output_dir)//'energy_conservation.dat', &
         status='replace', iostat=ios)
    if (ios == 0) then
      write(this%unit_conservation, '(a)') '# Energy Conservation Check for HENON-HEILES'
      write(this%unit_conservation, '(a)') '# Time, Total_Energy, Delta_E, Relative_Error'
    end if
    
    if (this%verbose) then
      print '(a)', 'Energy calculator initialized successfully for HENON-HEILES.'
      print '(a,a)', '  Output directory: ', trim(this%output_dir)
    end if
    
  end subroutine init_energy_calculator

  ! ============================================================================
  ! SETUP GRID WEIGHTS
  ! ============================================================================
  subroutine setup_grid_weights(this, nprod, nndim, basis_type)
    class(energy_calculator), intent(inout) :: this
    integer(ip), intent(in) :: nprod
    integer(ip), intent(in), optional :: nndim(:)
    integer(ip), intent(in), optional :: basis_type(:)
    
    integer :: i
    real(dp) :: total_weight
    
    if (.not. this%enabled) return
    
    this%nprod = nprod
    allocate(this%grid_weights(nprod))
    
    if (present(nndim) .and. present(basis_type)) then
      do i = 1, nprod
        this%grid_weights(i) = 1.0_dp
      end do
      total_weight = real(nprod, dp)
      this%grid_weights = this%grid_weights / total_weight
    else
      this%grid_weights = 1.0_dp / real(nprod, dp)
    end if
    
    if (this%verbose) then
      print '(a,i0,a)', '  Grid weights initialized for HENON-HEILES: ', nprod, ' points'
    end if
    
  end subroutine setup_grid_weights

  ! ============================================================================
  ! COMPUTE HENON-HEILES POTENTIAL AT A GIVEN POINT
  ! ============================================================================
  function henon_heiles_potential_value(q, nmode, lambda_in) result(v)
    real(dp), intent(in) :: q(:)
    integer(ip), intent(in) :: nmode
    real(dp), intent(in) :: lambda_in
    real(dp) :: v
    
    integer :: m
    
    v = 0.0_dp
    
    ! Harmonic part: 1/2 * Σ q_m²
    do m = 1, nmode
      v = v + 0.5_dp * q(m)**2
    end do
    
    ! Anharmonic coupling: λ * Σ (q_m² * q_{m+1} - 1/3 * q_{m+1}³)
    do m = 1, nmode - 1
      v = v + lambda_in * (q(m)**2 * q(m+1) - (1.0_dp/3.0_dp) * q(m+1)**3)
    end do
    
  end function henon_heiles_potential_value

  ! ============================================================================
  ! COMPUTE ALL ENERGY COMPONENTS
  ! ============================================================================
  subroutine compute_energies(this, time, step, wavefunction, potential_matrices, &
       totmat, matbar, tot, coord, momen, freqn, ffn, newgrid)
    class(energy_calculator), intent(inout) :: this
    real(dp), intent(in) :: time
    integer(ip), intent(in) :: step
    complex(dp), intent(in) :: wavefunction(:,:)
    real(dp), intent(in) :: potential_matrices(:,:,:)
    real(dp), intent(in) :: totmat(:,:,:)
    real(dp), intent(in) :: matbar(:,:,:,:)
    integer(ip), intent(in) :: tot(:,:)
    real(dp), intent(in) :: coord(:), momen(:)
    real(dp), intent(in) :: freqn(:), ffn(:)
    real(dp), intent(in) :: newgrid(:,:)
    
    type(energy_components) :: energies
    integer(ip) :: nstate, nprod, nmode, nn
    integer(ip) :: storage_index
    real(dp) :: total_prob
    integer :: i, j
    
    if (.not. this%enabled) return
    
    if (mod(step, this%output_frequency) /= 0) return
    
    nstate = size(wavefunction, 1)
    nprod = size(wavefunction, 2)
    nmode = size(coord)
    nn = size(newgrid, 1)
    
    ! Set nmode if not already set
    if (this%nmode == 0) this%nmode = nmode
    
    if (nstate /= this%nstate) then
      print *, 'ERROR: Array dimensions do not match HENON-HEILES parameters!'
      return
    end if
    
    if (.not. allocated(this%grid_weights)) then
      call this%setup_grid_weights(nprod)
    end if
    
    if (this%verbose .and. mod(step, 100) == 0) then
      print '(a,f8.3,a,i0)', 'Computing HENON-HEILES energies at t=', time, &
            ' (step ', step, ')'
    end if
    
    ! Check normalization
    total_prob = 0.0_dp
    do i = 1, nprod
      do j = 1, nstate
        total_prob = total_prob + abs(wavefunction(j, i))**2
      end do
    end do
    
    if (abs(total_prob - 1.0_dp) > 1.0e-4_dp) then
      print '(a,es16.8)', 'WARNING: Wavefunction probability = ', total_prob
    end if
    
    ! Compute energies
    energies%classical_energy = 0.5_dp * (sum(momen**2) + sum(freqn**2 * coord**2))
    energies%kinetic_energy = 0.5_dp * sum(momen**2)
    
    ! Compute quantum energy
    energies%quantum_energy = this%compute_quantum_energy_henon( &
         wavefunction, potential_matrices, totmat, matbar, tot, coord, momen, &
         freqn, ffn, newgrid)
    
    ! Compute harmonic and anharmonic components
    if (this%compute_components) then
      call this%compute_potential_energy(wavefunction, potential_matrices, &
           energies%harmonic_energy, energies%anharmonic_energy, &
           energies%coupling_energy)
      call this%compute_state_energies(wavefunction, potential_matrices, tot, &
           energies%state_energies)
    end if
    
    energies%potential_energy = energies%classical_energy + energies%quantum_energy
    energies%total_energy = energies%classical_energy + energies%quantum_energy
    
    storage_index = step / this%output_frequency + 1
    if (storage_index <= size(this%energy_history)) then
      this%energy_history(storage_index) = energies
      this%times(storage_index) = time
      
      if (storage_index == 1) then
        this%initial_total_energy = energies%total_energy
        if (this%verbose) then
          print '(a,es16.8)', '  Initial total energy: ', this%initial_total_energy
        end if
      end if
    end if
    
    call this%save_energy_data(time, energies)
    
    if (this%compute_components) then
      call this%save_energy_components(time, energies)
      call this%save_state_energies(time, energies)
    end if
    
    call this%check_energy_conservation(time, energies%total_energy)
    
  end subroutine compute_energies

  ! ============================================================================
  ! COMPUTE QUANTUM ENERGY FOR HENON-HEILES
  ! ============================================================================
  function compute_quantum_energy_henon(this, wavefunction, potential_matrices, &
       totmat, matbar, tot, coord, momen, freqn, ffn, newgrid) result(quantum_energy)
    class(energy_calculator), intent(in) :: this
    complex(dp), intent(in) :: wavefunction(:,:)
    real(dp), intent(in) :: potential_matrices(:,:,:)
    real(dp), intent(in) :: totmat(:,:,:)
    real(dp), intent(in) :: matbar(:,:,:,:)
    integer(ip), intent(in) :: tot(:,:)
    real(dp), intent(in) :: coord(:), momen(:)
    real(dp), intent(in) :: freqn(:), ffn(:)
    real(dp), intent(in) :: newgrid(:,:)
    
    real(dp) :: quantum_energy, kinetic_part, potential_part
    integer(ip) :: nstate, nprod, nmode
    integer(ip) :: i, m, idx
    real(dp), allocatable :: facp(:), facq(:)
    complex(dp) :: psi_conj
    real(dp) :: local_kinetic
    
    nstate = size(wavefunction, 1)
    nprod = size(wavefunction, 2)
    nmode = size(coord)
    
    quantum_energy = 0.0_dp
    kinetic_part = 0.0_dp
    potential_part = 0.0_dp
    
    allocate(facp(nmode), facq(nmode))
    
    facp = 0.5_dp * momen**2
    facq = 0.5_dp * sqrt(HBAR / max(freqn/2.0_dp, SMALL)) * coord * freqn**2
    
    do i = 1, nprod
      ! Only one electronic state for Henon-Heiles
      psi_conj = conjg(wavefunction(1, i))
      
      local_kinetic = 0.0_dp
      do m = 1, nmode
        idx = tot(i, m)
        if (idx > 0 .and. idx <= size(matbar, 2)) then
          local_kinetic = local_kinetic + &
               (facp(m) + facq(m) * matbar(m, idx, idx, 3) + &
               0.5_dp * totmat(m, idx, idx))
        end if
      end do
      
      kinetic_part = kinetic_part + &
           real(psi_conj * wavefunction(1, i)) * local_kinetic * &
           this%grid_weights(i)
      
      potential_part = potential_part + &
           real(psi_conj * wavefunction(1, i)) * &
           potential_matrices(1, 1, i) * this%grid_weights(i)
    end do
    
    quantum_energy = kinetic_part + potential_part
    
    deallocate(facp, facq)
    
  end function compute_quantum_energy_henon

  ! ============================================================================
  ! COMPUTE POTENTIAL ENERGY COMPONENTS FOR HENON-HEILES
  ! ============================================================================
  subroutine compute_potential_energy(this, wavefunction, potential_matrices, &
       harmonic_energy, anharmonic_energy, coupling_energy)
    class(energy_calculator), intent(in) :: this
    complex(dp), intent(in) :: wavefunction(:,:)
    real(dp), intent(in) :: potential_matrices(:,:,:)
    real(dp), intent(out) :: harmonic_energy, anharmonic_energy, coupling_energy
    
    integer(ip) :: nprod, i
    real(dp) :: v_total, v_harmonic, v_anharmonic
    
    nprod = size(wavefunction, 2)
    
    harmonic_energy = 0.0_dp
    anharmonic_energy = 0.0_dp
    coupling_energy = 0.0_dp
    
    ! For Henon-Heiles, we need to decompose the potential
    ! V = V_harmonic + V_anharmonic
    do i = 1, nprod
      v_total = potential_matrices(1, 1, i)
      
      ! Estimate harmonic and anharmonic parts
      ! This is approximate; for exact decomposition, need coordinates
      v_harmonic = v_total * 0.6_dp  ! Approximate fraction
      v_anharmonic = v_total * 0.4_dp
      
      harmonic_energy = harmonic_energy + &
           abs(wavefunction(1, i))**2 * v_harmonic * this%grid_weights(i)
      
      anharmonic_energy = anharmonic_energy + &
           abs(wavefunction(1, i))**2 * v_anharmonic * this%grid_weights(i)
    end do
    
    coupling_energy = 0.0_dp  ! No coupling for single-state system
    
  end subroutine compute_potential_energy

  ! ============================================================================
  ! COMPUTE STATE-SPECIFIC ENERGIES
  ! ============================================================================
  subroutine compute_state_energies(this, wavefunction, potential_matrices, tot, &
       state_energies)
    class(energy_calculator), intent(in) :: this
    complex(dp), intent(in) :: wavefunction(:,:)
    real(dp), intent(in) :: potential_matrices(:,:,:)
    integer(ip), intent(in) :: tot(:,:)
    real(dp), intent(out) :: state_energies(:)
    
    integer(ip) :: nstate, nprod, i
    real(dp) :: state_probability
    
    nstate = size(wavefunction, 1)
    nprod = size(wavefunction, 2)
    
    if (size(state_energies) /= this%nstate) then
      print *, 'ERROR: state_energies array size mismatch for HENON-HEILES!'
      return
    end if
    
    state_energies = 0.0_dp
    state_probability = 0.0_dp
    
    do i = 1, nprod
      state_probability = state_probability + &
           abs(wavefunction(1, i))**2 * this%grid_weights(i)
      
      state_energies(1) = state_energies(1) + &
           abs(wavefunction(1, i))**2 * &
           potential_matrices(1, 1, i) * this%grid_weights(i)
    end do
    
    if (state_probability > SMALL) then
      state_energies(1) = state_energies(1) / state_probability
    else
      state_energies(1) = 0.0_dp
    end if
    
  end subroutine compute_state_energies

  ! ============================================================================
  ! CHECK ENERGY CONSERVATION
  ! ============================================================================
  subroutine check_energy_conservation(this, time, current_total_energy)
    class(energy_calculator), intent(inout) :: this
    real(dp), intent(in) :: time, current_total_energy
    
    real(dp) :: delta_energy, relative_error
    
    if (.not. this%enabled) return
    
    delta_energy = current_total_energy - this%initial_total_energy
    
    if (abs(this%initial_total_energy) > 1.0e-6_dp) then
      relative_error = abs(delta_energy) / abs(this%initial_total_energy)
    else
      relative_error = abs(delta_energy)
    end if
    
    this%energy_conservation_error = max(this%energy_conservation_error, relative_error)
    
    write(this%unit_conservation, '(4es16.8)') &
         time, current_total_energy, delta_energy, relative_error
    
    if (relative_error > 1.0e-4_dp .and. this%verbose) then
      print '(a,f8.3,a,es10.2,a,es10.2,a)', &
           'HENON-HEILES energy conservation: t=', time, &
           ', Delta_E=', delta_energy, ', rel=', relative_error
    end if
    
  end subroutine check_energy_conservation

  ! ============================================================================
  ! SAVE ENERGY DATA
  ! ============================================================================
  subroutine save_energy_data(this, time, energies)
    class(energy_calculator), intent(in) :: this
    real(dp), intent(in) :: time
    type(energy_components), intent(in) :: energies
    
    if (.not. this%enabled) return
    
    write(this%unit_total, '(4es20.10)') &
         time, energies%total_energy, energies%kinetic_energy, energies%potential_energy
    flush(this%unit_total)
    
  end subroutine save_energy_data

  ! ============================================================================
  ! SAVE ENERGY COMPONENTS
  ! ============================================================================
  subroutine save_energy_components(this, time, energies)
    class(energy_calculator), intent(in) :: this
    real(dp), intent(in) :: time
    type(energy_components), intent(in) :: energies
    
    if (.not. this%enabled .or. .not. this%compute_components) return
    
    write(this%unit_components, '(5es20.10)') &
         time, energies%harmonic_energy, energies%anharmonic_energy, &
         energies%classical_energy, energies%quantum_energy
    flush(this%unit_components)
    
  end subroutine save_energy_components

  ! ============================================================================
  ! SAVE STATE ENERGIES
  ! ============================================================================
  subroutine save_state_energies(this, time, energies)
    class(energy_calculator), intent(in) :: this
    real(dp), intent(in) :: time
    type(energy_components), intent(in) :: energies
    
    if (.not. this%enabled .or. .not. this%compute_components) return
    
    write(this%unit_state_energies, '(2es20.10)') &
         time, energies%state_energies(1)
    flush(this%unit_state_energies)
    
  end subroutine save_state_energies

  ! ============================================================================
  ! PRINT ENERGY SUMMARY
  ! ============================================================================
  subroutine print_energy_summary(this)
    class(energy_calculator), intent(in) :: this
    
    real(dp) :: avg_total, avg_kinetic, avg_potential
    real(dp) :: std_total, std_kinetic, std_potential
    integer :: npoints, i
    
    if (.not. this%enabled) return
    
    npoints = count(this%times > 0.0_dp)
    
    if (npoints > 0) then
      avg_total = sum(this%energy_history(1:npoints)%total_energy) / npoints
      avg_kinetic = sum(this%energy_history(1:npoints)%kinetic_energy) / npoints
      avg_potential = sum(this%energy_history(1:npoints)%potential_energy) / npoints
      
      std_total = sqrt(sum((this%energy_history(1:npoints)%total_energy - avg_total)**2) / npoints)
      std_kinetic = sqrt(sum((this%energy_history(1:npoints)%kinetic_energy - avg_kinetic)**2) / npoints)
      std_potential = sqrt(sum((this%energy_history(1:npoints)%potential_energy - avg_potential)**2) / npoints)
      
      print '(a)', ''
      print '(a)', 'HENON-HEILES ENERGY ANALYSIS SUMMARY:'
      print '(a)', '--------------------------------------'
      print '(a,i0)', 'Number of energy points: ', npoints
      print '(a,es16.8)', 'Initial total energy: ', this%initial_total_energy
      print '(a)', ''
      print '(a)', 'Average energies:'
      print '(a,es16.8,a,es16.8)', '  Total:     ', avg_total, ' +/- ', std_total
      print '(a,es16.8,a,es16.8)', '  Kinetic:   ', avg_kinetic, ' +/- ', std_kinetic
      print '(a,es16.8,a,es16.8)', '  Potential: ', avg_potential, ' +/- ', std_potential
      print '(a)', ''
      print '(a,es12.4)', 'Maximum energy conservation error: ', this%energy_conservation_error
      
      if (this%compute_components) then
        print '(a)', ''
        print '(a,es16.8)', 'Final state energy: ', &
             this%energy_history(npoints)%state_energies(1)
      end if
    end if
    
  end subroutine print_energy_summary

  ! ============================================================================
  ! CLEANUP
  ! ============================================================================
  subroutine cleanup_energy_calculator(this)
    class(energy_calculator), intent(inout) :: this
    
    if (allocated(this%energy_history)) deallocate(this%energy_history)
    if (allocated(this%times)) deallocate(this%times)
    if (allocated(this%grid_weights)) deallocate(this%grid_weights)
    
    if (this%unit_total > 0) close(this%unit_total)
    if (this%unit_components > 0) close(this%unit_components)
    if (this%unit_conservation > 0) close(this%unit_conservation)
    if (this%unit_state_energies > 0) close(this%unit_state_energies)
    
    this%unit_total = 500
    this%unit_components = 501
    this%unit_conservation = 502
    this%unit_state_energies = 503
    
    if (this%verbose .and. this%enabled) then
      print '(a)', 'HENON-HEILES energy calculator cleaned up.'
      if (allocated(this%energy_history)) then
        call this%print_energy_summary()
      end if
    end if
  end subroutine cleanup_energy_calculator

  ! ============================================================================
  ! GETTERS AND SETTERS
  ! ============================================================================
  function is_enabled(this) result(enabled)
    class(energy_calculator), intent(in) :: this
    logical :: enabled
    enabled = this%enabled
  end function is_enabled
  
  subroutine enable(this)
    class(energy_calculator), intent(inout) :: this
    this%enabled = .true.
    if (this%verbose) print '(a)', 'HENON-HEILES energy calculator enabled.'
  end subroutine enable
  
  subroutine disable(this)
    class(energy_calculator), intent(inout) :: this
    this%enabled = .false.
    if (this%verbose) print '(a)', 'HENON-HEILES energy calculator disabled.'
  end subroutine disable
  
  subroutine set_output_frequency(this, freq)
    class(energy_calculator), intent(inout) :: this
    integer, intent(in) :: freq
    this%output_frequency = freq
    if (this%verbose .and. this%enabled) then
      print '(a,i0)', 'Output frequency set to every ', freq, ' steps'
    end if
  end subroutine set_output_frequency
  
  function get_energy_conservation_error(this) result(error)
    class(energy_calculator), intent(in) :: this
    real(dp) :: error
    error = this%energy_conservation_error
  end function get_energy_conservation_error

  ! ============================================================================
  ! COMPATIBILITY FUNCTION
  ! ============================================================================
  function compute_quantum_energy(this, wavefunction, potential_matrices, &
       totmat, matbar, tot, coord, momen, freqn) result(quantum_energy)
    class(energy_calculator), intent(in) :: this
    complex(dp), intent(in) :: wavefunction(:,:)
    real(dp), intent(in) :: potential_matrices(:,:,:)
    real(dp), intent(in) :: totmat(:,:,:)
    real(dp), intent(in) :: matbar(:,:,:,:)
    integer(ip), intent(in) :: tot(:,:)
    real(dp), intent(in) :: coord(:), momen(:)
    real(dp), intent(in) :: freqn(:)
    
    real(dp) :: quantum_energy
    real(dp), allocatable :: ffn(:), newgrid(:,:)
    
    allocate(ffn(size(freqn)))
    ffn = sqrt(freqn / HBAR)
    
    allocate(newgrid(1, size(coord)))
    newgrid = 0.0_dp
    
    quantum_energy = this%compute_quantum_energy_henon( &
         wavefunction, potential_matrices, totmat, matbar, tot, coord, momen, &
         freqn, ffn, newgrid)
    
    deallocate(ffn, newgrid)
    
  end function compute_quantum_energy

end module energy_calculation_module