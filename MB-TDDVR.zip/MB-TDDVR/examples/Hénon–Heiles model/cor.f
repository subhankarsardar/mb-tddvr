      IMPLICIT REAL*8(A-H,O-Z)
      COMPLEX*16 ZI,DD,AB,AC
      PARAMETER (NN=1700)
      PARAMETER (MM=1700)
      DIMENSION TT(-NN:NN)
      DIMENSION DD(-NN:NN)
      COMMON/DELT/DT
      COMMON/AK/AKT(MM)
      PI=4.0D0*DATAN(1.0D0)
      HBAR=0.06350781278D0
      EVS=0.9648455078D0
      ZI=DCMPLX(0.0D0,1.0D0)
      TAU=3.40D0
CCC
      DO I=1,NN
      READ(5,*)T,a,CT1,CT2
      J=-I
      TT(I)=T
      TT(J)=-T
      DD(I)=DCMPLX(CT1,CT2)
      DD(J)=DCMPLX(CT1,-CT2)
      WRITE(2,66)TT(I),TT(J)
      ENDDO
      DO I=1,NN
      J=-I
      DD(I)=DD(I)*(DCOS(PI*TT(I)/(2*TT(NN))))**2*EXP(-(TT(I)/TAU)**2)
      DD(J)=DD(J)*(DCOS(PI*TT(J)/(2*TT(-NN))))**2*EXP(-(TT(J)/TAU)**2)
      ENDDO
      DT=TT(NN)/DFLOAT(NN)
      CALL DEFAK
      WRITE(2,*)
      AL1=140.0
      AL2=277.0
c     AL1=140.0
c     AL2=317.0
      DAL=(AL2-AL1)/DFLOAT(MM)
      DO I=1,MM
      AKT(I)=2.0D0*PI*3000.0/(AL1+(I-1)*DAL)
      ENDDO
c     FAC=-2.81*EVS/HBAR
      FAC=-6.16*EVS/HBAR
      DO I=1,MM
      AB=DCMPLX(0.0D0,0.0D0)
      AC=DCMPLX(0.0D0,0.0D0)
      DO J=-NN,NN,1
      AB=AB+AKT(I)*DD(J)*EXP(ZI*(AKT(I)+FAC)*TT(J))*DT
      AC=AC+DD(J)*EXP(ZI*(AKT(I)+FAC)*TT(J))*DT
      ENDDO
      P=2.0D0*PI*3000.0D0/AKT(I)
      WRITE(6,77)AKT(I)*HBAR/EVS,P,ABS((DBLE(AB)))/2.0,ABS(DBLE(AC))
      ENDDO
  66  FORMAT(2x,11F12.6)

  77  FORMAT(2x,5F16.6)
      STOP
      END
CCCC
            SUBROUTINE DEFAK
*
*     CALCULATION OF FREQUENCIES
*
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER(MM=1700)
*
      COMMON/DELT/DT
      COMMON/AK/AKT(MM)
*
      PI=2.*ASIN(1.)
      PI2=PI*2.
      ACONS=PI2/(MM*DT)
      NHALF = MM/2+1
        DO 1 I=1,NHALF
          AKT(I)=ACONS*(I-1)
  1     CONTINUE
        DO 2 I=NHALF+1,MM
          AKT(I)=ACONS*(I-1-MM)
  2     CONTINUE
        RETURN
        END
