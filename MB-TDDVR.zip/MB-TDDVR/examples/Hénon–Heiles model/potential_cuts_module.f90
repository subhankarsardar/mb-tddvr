! ============================================================================
! 1D POTENTIAL CUTS MODULE FOR HENON-HEILES SYSTEM
! Creates 1D potential cuts along specified modes
! Compatible with Henon-Heiles TDDVR simulations
! Based on: J. Chem. Phys. 117, 10499 (2002)
! ============================================================================

module potential_cuts_module
  use, intrinsic :: iso_fortran_env, only: real64, int32
  implicit none
  
  private
  
  ! Public types and procedures
  public :: potential_cuts_analyzer, dp, ip
  public :: create_potential_analyzer
  public :: set_henon_heiles_lambda_cuts
  
  ! Kind parameters
  integer, parameter :: dp = real64
  integer, parameter :: ip = int32
  
  ! Default modes to analyze (first few modes for Henon-Heiles)
  integer, parameter :: DEFAULT_NMODES = 4
  integer, parameter :: DEFAULT_MODES(4) = [1, 2, 3, 4]
  
  ! Plotting parameters
  integer, parameter :: N_POINTS = 100
  real(dp), parameter :: CUT_RANGE = 4.0_dp
  real(dp), parameter :: SMALL = 1.0e-12_dp
  
  ! Henon-Heiles lambda parameter
  real(dp), private :: lambda_henon_cuts = 0.111803398875_dp  ! 1/√80
  
  ! Type for potential cuts analyzer
  type :: potential_cuts_analyzer
    private
    logical :: enabled = .false.
    logical :: verbose = .true.
    logical :: parallel = .true.
    
    ! Modes to analyze
    integer(ip) :: nmodes_to_analyze = DEFAULT_NMODES
    integer(ip), allocatable :: modes_to_analyze(:)
    
    ! Output control
    integer :: output_frequency = 50
    character(len=100) :: output_dir = "./potential_cuts/"
    
    ! Internal storage
    real(dp), allocatable :: potential_cuts(:,:)      ! (N_POINTS, nmodes)
    real(dp), allocatable :: coordinates(:,:)         ! (N_POINTS, nmodes)
    real(dp), allocatable :: times(:)
    real(dp), allocatable :: min_potentials(:)        ! (nmodes)
    real(dp), allocatable :: max_potentials(:)        ! (nmodes)
    real(dp), allocatable :: min_coords(:)            ! (nmodes)
    real(dp), allocatable :: max_coords(:)            ! (nmodes)
    
    ! File units
    integer :: unit_summary = -1
    
    ! Counters
    integer :: cut_counter = 0
    integer :: max_time_steps = 10000
    integer(ip) :: nmode = 0
    real(dp) :: lambda = 0.111803398875_dp
    
  contains
    procedure :: initialize => init_potential_analyzer
    procedure :: set_modes_to_analyze
    procedure :: compute_1d_potential_cuts
    procedure :: compute_1d_potential_cuts_direct
    procedure :: find_minima_maxima
    procedure :: save_potential_data
    procedure :: save_summary_data
    procedure :: generate_gnuplot_scripts
    procedure :: finalize => cleanup_potential_analyzer
    procedure :: is_enabled
    procedure :: enable
    procedure :: disable
    procedure :: set_output_frequency
    procedure :: get_min_potentials
    procedure :: get_max_potentials
    procedure :: set_lambda
    procedure :: compute_potential_value
  end type potential_cuts_analyzer
  
  ! Constructor interface
  interface potential_cuts_analyzer
    module procedure create_potential_analyzer
  end interface

contains

  ! ============================================================================
  ! SET LAMBDA
  ! ============================================================================
  subroutine set_henon_heiles_lambda_cuts(lambda_in)
    real(dp), intent(in) :: lambda_in
    lambda_henon_cuts = lambda_in
  end subroutine set_henon_heiles_lambda_cuts

  ! ============================================================================
  ! CONSTRUCTOR
  ! ============================================================================
  function create_potential_analyzer(enabled, verbose, parallel, &
                                    modes_list, output_freq) result(analyzer)
    logical, intent(in), optional :: enabled, verbose, parallel
    integer(ip), intent(in), optional :: modes_list(:)
    integer, intent(in), optional :: output_freq
    type(potential_cuts_analyzer) :: analyzer
    
    if (present(enabled)) analyzer%enabled = enabled
    if (present(verbose)) analyzer%verbose = verbose
    if (present(parallel)) analyzer%parallel = parallel
    if (present(output_freq)) analyzer%output_frequency = output_freq
    
    analyzer%lambda = lambda_henon_cuts
    
    if (present(modes_list)) then
      analyzer%nmodes_to_analyze = size(modes_list)
      allocate(analyzer%modes_to_analyze(analyzer%nmodes_to_analyze))
      analyzer%modes_to_analyze = modes_list
    else
      allocate(analyzer%modes_to_analyze(DEFAULT_NMODES))
      analyzer%modes_to_analyze = DEFAULT_MODES
    end if
    
    if (analyzer%verbose .and. analyzer%enabled) then
      print '(a)', "Potential cuts analyzer created for HENON-HEILES (enabled)"
      print '(a,i0)', "  Modes to analyze: ", analyzer%nmodes_to_analyze
      print '(a,*(i4))', "  Mode list: ", analyzer%modes_to_analyze
      print '(a,f8.4)', "  Lambda: ", analyzer%lambda
      print '(a,i0)', "  Output frequency: every ", analyzer%output_frequency, " steps"
      if (analyzer%parallel) print '(a)', "  Parallel execution: enabled"
    end if
  end function create_potential_analyzer

  ! ============================================================================
  ! SET LAMBDA
  ! ============================================================================
  subroutine set_lambda(this, lambda_in)
    class(potential_cuts_analyzer), intent(inout) :: this
    real(dp), intent(in) :: lambda_in
    this%lambda = lambda_in
    lambda_henon_cuts = lambda_in
    if (this%verbose) then
      print '(a,es12.4)', "Potential cuts analyzer lambda set to: ", lambda_in
    end if
  end subroutine set_lambda

  ! ============================================================================
  ! COMPUTE HENON-HEILES POTENTIAL VALUE
  ! ============================================================================
  function compute_potential_value(this, q, nmode) result(v)
    class(potential_cuts_analyzer), intent(in) :: this
    real(dp), intent(in) :: q(:)
    integer(ip), intent(in) :: nmode
    real(dp) :: v
    
    integer :: m
    
    v = 0.0_dp
    
    ! Harmonic part: 1/2 * Σ q_m²
    do m = 1, nmode
      v = v + 0.5_dp * q(m)**2
    end do
    
    ! Anharmonic coupling: λ * Σ (q_m² * q_{m+1} - 1/3 * q_{m+1}³)
    do m = 1, nmode - 1
      v = v + this%lambda * (q(m)**2 * q(m+1) - (1.0_dp/3.0_dp) * q(m+1)**3)
    end do
    
  end function compute_potential_value

  ! ============================================================================
  ! INITIALIZE POTENTIAL ANALYZER
  ! ============================================================================
  subroutine init_potential_analyzer(this, nstate, nmode, freqn, ffn)
    class(potential_cuts_analyzer), intent(inout) :: this
    integer(ip), intent(in) :: nstate, nmode
    real(dp), intent(in) :: freqn(:), ffn(:)
    
    integer :: ios, i, m, j
    character(len=200) :: dir_command
    real(dp) :: dx
    
    if (.not. this%enabled) return
    
    this%nmode = nmode
    this%lambda = lambda_henon_cuts
    
    if (this%verbose) then
      print '(a)', "Initializing potential cuts analyzer for HENON-HEILES..."
      print '(a,i0)', "  Total modes: ", nmode
      print '(a,f8.4)', "  Lambda: ", this%lambda
    end if
    
    ! Check mode indices are valid
    do i = 1, this%nmodes_to_analyze
      m = this%modes_to_analyze(i)
      if (m < 1 .or. m > nmode) then
        print '(a,i0,a)', "ERROR: Mode ", m, " is out of bounds!"
        this%enabled = .false.
        return
      end if
    end do
    
    ! Allocate storage (single state)
    allocate(this%potential_cuts(N_POINTS, this%nmodes_to_analyze))
    allocate(this%coordinates(N_POINTS, this%nmodes_to_analyze))
    allocate(this%min_potentials(this%nmodes_to_analyze))
    allocate(this%max_potentials(this%nmodes_to_analyze))
    allocate(this%min_coords(this%nmodes_to_analyze))
    allocate(this%max_coords(this%nmodes_to_analyze))
    allocate(this%times(this%max_time_steps))
    
    ! Initialize coordinate grid
    dx = 2.0_dp * CUT_RANGE / real(N_POINTS - 1, dp)
    do i = 1, this%nmodes_to_analyze
      m = this%modes_to_analyze(i)
      do j = 1, N_POINTS
        this%coordinates(j, i) = -CUT_RANGE + (j-1) * dx
        ! Scale by frequency for better visualization
        if (freqn(m) > SMALL) then
          this%coordinates(j, i) = this%coordinates(j, i) / sqrt(2.0_dp * freqn(m))
        end if
      end do
    end do
    
    this%potential_cuts = 0.0_dp
    this%min_potentials = huge(1.0_dp)
    this%max_potentials = -huge(1.0_dp)
    this%min_coords = 0.0_dp
    this%max_coords = 0.0_dp
    this%times = 0.0_dp
    this%cut_counter = 0
    
    dir_command = "mkdir -p " // trim(this%output_dir)
    call system(dir_command)
    
    open(newunit=this%unit_summary, &
         file=trim(this%output_dir)//"henon_heiles_potential_summary.dat", &
         status='replace', iostat=ios)
    if (ios == 0) then
      write(this%unit_summary, '(a)') '# Henon-Heiles Potential Minima and Maxima Summary'
      write(this%unit_summary, '(a)') '# Time, Mode, Min_Potential, Max_Potential, Min_Coord, Max_Coord'
    end if
    
    if (this%verbose) then
      print '(a)', "Potential cuts analyzer initialized successfully."
      print '(a,a)', "  Output directory: ", trim(this%output_dir)
    end if
  end subroutine init_potential_analyzer

  ! ============================================================================
  ! SET MODES TO ANALYZE
  ! ============================================================================
  subroutine set_modes_to_analyze(this, modes_list)
    class(potential_cuts_analyzer), intent(inout) :: this
    integer(ip), intent(in) :: modes_list(:)
    
    if (allocated(this%modes_to_analyze)) deallocate(this%modes_to_analyze)
    
    this%nmodes_to_analyze = size(modes_list)
    allocate(this%modes_to_analyze(this%nmodes_to_analyze))
    this%modes_to_analyze = modes_list
    
    if (this%verbose .and. this%enabled) then
      print '(a,i0)', "Updated modes to analyze: ", this%nmodes_to_analyze
      print '(a,*(i4))', "  New mode list: ", this%modes_to_analyze
    end if
  end subroutine set_modes_to_analyze

  ! ============================================================================
  ! COMPUTE 1D POTENTIAL CUTS
  ! ============================================================================
  subroutine compute_1d_potential_cuts(this, time, step, potential_func, &
                                      freqn, ffn, center_coords)
    class(potential_cuts_analyzer), intent(inout) :: this
    real(dp), intent(in) :: time
    integer(ip), intent(in) :: step
    interface
      function potential_func(coords, nstate) result(v)
        import dp, ip
        real(dp), intent(in) :: coords(:)
        integer(ip), intent(in) :: nstate
        real(dp) :: v(:, :)
      end function potential_func
    end interface
    real(dp), intent(in) :: freqn(:), ffn(:)
    real(dp), intent(in) :: center_coords(:)
    
    integer(ip) :: i, j, m, nmode_local
    real(dp), allocatable :: coords(:)
    real(dp), allocatable :: v_diag(:,:)
    integer :: time_idx
    
    if (.not. this%enabled) return
    if (mod(step, this%output_frequency) /= 0) return
    
    nmode_local = this%nmode
    
    allocate(coords(nmode_local))
    allocate(v_diag(1, 1))
    
    this%cut_counter = this%cut_counter + 1
    time_idx = this%cut_counter
    
    if (time_idx <= size(this%times)) then
      this%times(time_idx) = time
    end if
    
    if (this%verbose .and. mod(step, 100) == 0) then
      print '(a,f8.3,a,i0)', "Computing 1D potential cuts at t=", time, &
            " (step ", step, ")"
    end if
    
    do i = 1, this%nmodes_to_analyze
      m = this%modes_to_analyze(i)
      
      do j = 1, N_POINTS
        coords = center_coords
        coords(m) = this%coordinates(j, i)
        v_diag = potential_func(coords, 1)
        this%potential_cuts(j, i) = v_diag(1, 1)
      end do
    end do
    
    deallocate(coords, v_diag)
    
    call this%find_minima_maxima()
    call this%save_potential_data(time, step)
    call this%save_summary_data(time, step)
  end subroutine compute_1d_potential_cuts

  ! ============================================================================
  ! COMPUTE 1D POTENTIAL CUTS DIRECTLY (NO FUNCTION INTERFACE)
  ! ============================================================================
  subroutine compute_1d_potential_cuts_direct(this, time, step, &
                                              center_coords, freqn)
    class(potential_cuts_analyzer), intent(inout) :: this
    real(dp), intent(in) :: time
    integer(ip), intent(in) :: step
    real(dp), intent(in) :: center_coords(:)
    real(dp), intent(in) :: freqn(:)
    
    integer(ip) :: i, j, m, nmode_local
    real(dp), allocatable :: coords(:)
    integer :: time_idx
    
    if (.not. this%enabled) return
    if (mod(step, this%output_frequency) /= 0) return
    
    nmode_local = this%nmode
    
    allocate(coords(nmode_local))
    
    this%cut_counter = this%cut_counter + 1
    time_idx = this%cut_counter
    
    if (time_idx <= size(this%times)) then
      this%times(time_idx) = time
    end if
    
    if (this%verbose .and. mod(step, 100) == 0) then
      print '(a,f8.3,a,i0)', "Computing 1D potential cuts at t=", time, &
            " (step ", step, ")"
    end if
    
    do i = 1, this%nmodes_to_analyze
      m = this%modes_to_analyze(i)
      
      do j = 1, N_POINTS
        coords = center_coords
        coords(m) = this%coordinates(j, i)
        this%potential_cuts(j, i) = this%compute_potential_value(coords, nmode_local)
      end do
    end do
    
    deallocate(coords)
    
    call this%find_minima_maxima()
    call this%save_potential_data(time, step)
    call this%save_summary_data(time, step)
  end subroutine compute_1d_potential_cuts_direct

  ! ============================================================================
  ! FIND POTENTIAL MINIMA AND MAXIMA
  ! ============================================================================
  subroutine find_minima_maxima(this)
    class(potential_cuts_analyzer), intent(inout) :: this
    
    integer(ip) :: i, min_idx, max_idx
    
    if (.not. this%enabled) return
    
    do i = 1, this%nmodes_to_analyze
      this%min_potentials(i) = minval(this%potential_cuts(:, i))
      this%max_potentials(i) = maxval(this%potential_cuts(:, i))
      
      min_idx = minloc(this%potential_cuts(:, i), dim=1)
      max_idx = maxloc(this%potential_cuts(:, i), dim=1)
      
      this%min_coords(i) = this%coordinates(min_idx, i)
      this%max_coords(i) = this%coordinates(max_idx, i)
      
      if (this%verbose) then
        print '(a,i0,a,f12.6,a,f8.4)', &
              "Mode ", this%modes_to_analyze(i), &
              ": Min = ", this%min_potentials(i), &
              " at x = ", this%min_coords(i)
        print '(a,f12.6,a,f8.4)', &
              "                  Max = ", this%max_potentials(i), &
              " at x = ", this%max_coords(i)
      end if
    end do
  end subroutine find_minima_maxima

  ! ============================================================================
  ! SAVE POTENTIAL DATA
  ! ============================================================================
  subroutine save_potential_data(this, time, step)
    class(potential_cuts_analyzer), intent(in) :: this
    real(dp), intent(in) :: time
    integer(ip), intent(in) :: step
    
    character(len=200) :: filename
    integer :: i, j, unit_file, m
    
    if (.not. this%enabled) return
    
    do i = 1, this%nmodes_to_analyze
      m = this%modes_to_analyze(i)
      
      write(filename, '(a,i3.3,a,f8.3,a)') &
            trim(this%output_dir) // "henon_heiles_potential_mode", m, &
            "_t", time, ".dat"
      
      open(newunit=unit_file, file=trim(filename), status='replace')
      
      write(unit_file, '(a)') '# 1D Potential Cuts for Henon-Heiles'
      write(unit_file, '(a,f12.6,a,i0)') '# Time: ', time, ', Step: ', step
      write(unit_file, '(a,i0)') '# Mode: ', m
      write(unit_file, '(a,f8.4)') '# Lambda: ', this%lambda
      write(unit_file, '(a)') '# Coordinate, Potential_Energy'
      
      do j = 1, N_POINTS
        write(unit_file, '(2f16.8)') &
              this%coordinates(j, i), this%potential_cuts(j, i)
      end do
      
      close(unit_file)
    end do
    
    ! Combined file
    write(filename, '(a,f8.3,a)') &
          trim(this%output_dir) // "henon_heiles_potential_all_modes_t", time, ".dat"
    
    open(newunit=unit_file, file=trim(filename), status='replace')
    write(unit_file, '(a)') '# Combined 1D Potential Cuts for All Modes'
    write(unit_file, '(a,f12.6)') '# Time: ', time
    write(unit_file, '(a,f8.4)') '# Lambda: ', this%lambda
    write(unit_file, '(a)') '# Format: Mode, Coordinate, Potential_Energy'
    
    do i = 1, this%nmodes_to_analyze
      m = this%modes_to_analyze(i)
      write(unit_file, '(a,i0)') '# Mode ', m
      do j = 1, N_POINTS
        write(unit_file, '(i4,2f16.8)') &
              m, this%coordinates(j, i), this%potential_cuts(j, i)
      end do
      write(unit_file, *)
    end do
    
    close(unit_file)
  end subroutine save_potential_data

  ! ============================================================================
  ! SAVE SUMMARY DATA
  ! ============================================================================
  subroutine save_summary_data(this, time, step)
    class(potential_cuts_analyzer), intent(in) :: this
    real(dp), intent(in) :: time
    integer(ip), intent(in) :: step
    
    integer(ip) :: i, m
    
    if (.not. this%enabled) return
    if (this%unit_summary < 0) return
    
    do i = 1, this%nmodes_to_analyze
      m = this%modes_to_analyze(i)
      
      write(this%unit_summary, '(f12.6,i6,4f16.8)') &
            time, m, &
            this%min_potentials(i), &
            this%max_potentials(i), &
            this%min_coords(i), &
            this%max_coords(i)
    end do
    
    flush(this%unit_summary)
  end subroutine save_summary_data

  ! ============================================================================
  ! GENERATE GNUPLOT SCRIPTS
  ! ============================================================================
  subroutine generate_gnuplot_scripts(this)
    class(potential_cuts_analyzer), intent(in) :: this
    
    character(len=200) :: scriptname
    integer :: unit, i, m, idx
    
    if (.not. this%enabled) return
    
    do i = 1, this%nmodes_to_analyze
      m = this%modes_to_analyze(i)
      
      scriptname = trim(this%output_dir) // "plot_henon_heiles_potential_mode" // &
                   trim(int_to_str(m)) // ".gnu"
      
      open(newunit=unit, file=trim(scriptname), status='replace')
      
      write(unit, '(a)') '# Gnuplot script for 1D potential cuts'
      write(unit, '(a)') 'set terminal pngcairo enhanced size 1000,700'
      write(unit, '(a,i0,a)') 'set output "' // trim(this%output_dir) // 'henon_heiles_potential_mode', m, '.png"'
      write(unit, '(a)') ''
      write(unit, '(a)') '# Plot settings'
      write(unit, '(a,i0,a)') 'set title "Henon-Heiles 1D Potential Cuts - Mode ', m, '"'
      write(unit, '(a,f8.4)') 'set label 1 "Lambda = ', this%lambda, '" at graph 0.02,0.95'
      write(unit, '(a)') 'set xlabel "Coordinate"'
      write(unit, '(a)') 'set ylabel "Potential Energy"'
      write(unit, '(a)') 'set grid'
      write(unit, '(a)') 'set key outside right top'
      write(unit, '(a)') ''
      write(unit, '(a)') '# Define line styles'
      write(unit, '(a)') 'set style line 1 lc rgb "#FF0000" lw 2'
      write(unit, '(a)') 'set style line 2 lc rgb "#0000FF" lw 2 dt 2'
      write(unit, '(a)') ''
      write(unit, '(a)') '# Potential cut'
      write(unit, '(a)') 'plot \'
      write(unit, '(a,i0,a)') '  "' // trim(this%output_dir) // 'henon_heiles_potential_mode', m, '.dat" u 1:2 w l ls 1 t "Potential", \'
      write(unit, '(a)') '  "' // trim(this%output_dir) // 'henon_heiles_potential_mode' // trim(int_to_str(m)) // '.dat" u 1:2:3 w labels notitle'
      
      close(unit)
    end do
    
    ! Script for comparing all modes
    scriptname = trim(this%output_dir) // "plot_henon_heiles_all_modes_comparison.gnu"
    open(newunit=unit, file=trim(scriptname), status='replace')
    
    write(unit, '(a)') '# Gnuplot script for comparing all modes'
    write(unit, '(a)') 'set terminal pngcairo enhanced size 1600,1200'
    write(unit, '(a)') 'set output "' // trim(this%output_dir) // 'henon_heiles_all_modes_comparison.png"'
    write(unit, '(a)') 'set multiplot layout 2,2'
    write(unit, '(a)') ''
    
    do i = 1, min(this%nmodes_to_analyze, 4)
      m = this%modes_to_analyze(i)
      write(unit, '(a,i0,a)') 'set title "Mode ', m, '"'
      write(unit, '(a)') 'set xlabel "Coordinate"'
      write(unit, '(a)') 'set ylabel "Potential"'
      write(unit, '(a)') 'set grid'
      write(unit, '(a,i0,a)') 'plot "' // trim(this%output_dir) // 'henon_heiles_potential_mode', m, '.dat" u 1:2 w l t ""'
      write(unit, '(a)') ''
    end do
    
    write(unit, '(a)') 'unset multiplot'
    close(unit)
    
    if (this%verbose) then
      print '(a,a)', "Gnuplot scripts generated in ", trim(this%output_dir)
    end if
    
  contains
    function int_to_str(i) result(str)
      integer, intent(in) :: i
      character(len=20) :: str
      write(str, '(i0)') i
      str = adjustl(str)
    end function int_to_str
  end subroutine generate_gnuplot_scripts

  ! ============================================================================
  ! CLEANUP
  ! ============================================================================
  subroutine cleanup_potential_analyzer(this)
    class(potential_cuts_analyzer), intent(inout) :: this
    
    if (allocated(this%potential_cuts)) deallocate(this%potential_cuts)
    if (allocated(this%coordinates)) deallocate(this%coordinates)
    if (allocated(this%times)) deallocate(this%times)
    if (allocated(this%min_potentials)) deallocate(this%min_potentials)
    if (allocated(this%max_potentials)) deallocate(this%max_potentials)
    if (allocated(this%min_coords)) deallocate(this%min_coords)
    if (allocated(this%max_coords)) deallocate(this%max_coords)
    if (allocated(this%modes_to_analyze)) deallocate(this%modes_to_analyze)
    
    if (this%unit_summary > 0) then
      close(this%unit_summary)
      this%unit_summary = -1
    end if
    
    if (this%verbose .and. this%enabled) then
      print '(a,i0,a)', "Potential cuts analyzer cleaned up. Generated ", &
            this%cut_counter, " potential cuts."
    end if
  end subroutine cleanup_potential_analyzer

  ! ============================================================================
  ! GETTERS AND SETTERS
  ! ============================================================================
  function is_enabled(this) result(enabled)
    class(potential_cuts_analyzer), intent(in) :: this
    logical :: enabled
    enabled = this%enabled
  end function is_enabled
  
  subroutine enable(this)
    class(potential_cuts_analyzer), intent(inout) :: this
    this%enabled = .true.
    if (this%verbose) print '(a)', "Potential cuts analyzer enabled."
  end subroutine enable
  
  subroutine disable(this)
    class(potential_cuts_analyzer), intent(inout) :: this
    this%enabled = .false.
    if (this%verbose) print '(a)', "Potential cuts analyzer disabled."
  end subroutine disable
  
  subroutine set_output_frequency(this, freq)
    class(potential_cuts_analyzer), intent(inout) :: this
    integer, intent(in) :: freq
    this%output_frequency = freq
    if (this%verbose .and. this%enabled) then
      print '(a,i0)', "Output frequency set to every ", freq, " steps"
    end if
  end subroutine set_output_frequency
  
  function get_min_potentials(this) result(min_pots)
    class(potential_cuts_analyzer), intent(in) :: this
    real(dp), allocatable :: min_pots(:)
    
    if (allocated(this%min_potentials)) then
      allocate(min_pots(size(this%min_potentials)))
      min_pots = this%min_potentials
    else
      allocate(min_pots(0))
    end if
  end function get_min_potentials
  
  function get_max_potentials(this) result(max_pots)
    class(potential_cuts_analyzer), intent(in) :: this
    real(dp), allocatable :: max_pots(:)
    
    if (allocated(this%max_potentials)) then
      allocate(max_pots(size(this%max_potentials)))
      max_pots = this%max_potentials
    else
      allocate(max_pots(0))
    end if
  end function get_max_potentials

end module potential_cuts_module