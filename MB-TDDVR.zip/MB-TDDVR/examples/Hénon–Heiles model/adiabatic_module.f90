! ============================================================================
! ADIABATIC POTENTIAL ENERGY ANALYSIS MODULE - HENON-HEILES VERSION
! Compatible with Henon-Heiles TDDVR simulations
! Analyzes potential energy surface and provides energy decomposition
! Based on: J. Chem. Phys. 117, 10499 (2002)
! ============================================================================

module adiabatic_module
  use, intrinsic :: iso_fortran_env, only: real64, int32
  implicit none
  
  private
  
  ! Public types and procedures
  public :: adiabatic_calculator, dp, ip
  public :: create_adiabatic_calculator
  public :: set_henon_heiles_lambda_adiabatic
  
  ! Kind parameters
  integer, parameter :: dp = real64
  integer, parameter :: ip = int32
  
  ! Constants
  real(dp), parameter :: SMALL = 1.0e-12_dp
  real(dp), parameter :: PI = 3.14159265358979323846_dp
  
  ! Henon-Heiles anharmonicity parameter (shared with energy module)
  real(dp), private :: lambda_henon_adiabatic = 0.111803398875_dp  ! 1/√80
  
  ! Type for adiabatic calculator
  type :: adiabatic_calculator
    private
    logical :: enabled = .false.
    logical :: verbose = .true.
    logical :: parallel = .true.
    logical :: store_potential_data = .true.
    
    ! Storage for potential energy data
    real(dp), allocatable :: potential_energy(:,:)       ! (1, nnprod)
    real(dp), allocatable :: harmonic_energy(:,:)        ! (1, nnprod)
    real(dp), allocatable :: anharmonic_energy(:,:)      ! (1, nnprod)
    real(dp), allocatable :: potential_energy_time(:,:)  ! (1, tstep)
    real(dp), allocatable :: times(:)                    ! (tstep)
    
    ! Output file units
    integer :: file_unit_potential = 400
    integer :: file_unit_components = 401
    integer :: file_unit_stats = 402
    
    ! Parameters
    integer(ip) :: nstate = 1
    integer(ip) :: nnprod = 0
    integer(ip) :: tstep = 0
    integer(ip) :: current_step = 0
    
    ! Output directory
    character(len=100) :: output_dir = "./adiabatic_analysis/"
    
    ! Statistics
    real(dp) :: compute_time = 0.0_dp
    real(dp) :: min_potential = 0.0_dp
    real(dp) :: max_potential = 0.0_dp
    real(dp) :: mean_potential = 0.0_dp
    real(dp) :: std_potential = 0.0_dp
    
  contains
    procedure :: initialize => init_adiabatic
    procedure :: compute_transformation
    procedure :: transform_wavefunction
    procedure :: compute_adiabatic_populations
    procedure :: analyze_potential_energy
    procedure :: write_potential_data
    procedure :: write_potential_components
    procedure :: finalize => cleanup_adiabatic
    procedure :: is_enabled
    procedure :: enable
    procedure :: disable
    procedure :: set_output_dir
    procedure :: get_potential_energy
    procedure :: get_potential_statistics
    procedure :: set_lambda
  end type adiabatic_calculator
  
  ! Interface for constructor
  interface adiabatic_calculator
    module procedure create_calculator
  end interface

contains

  ! ============================================================================
  ! SET LAMBDA
  ! ============================================================================
  subroutine set_henon_heiles_lambda_adiabatic(lambda_in)
    real(dp), intent(in) :: lambda_in
    lambda_henon_adiabatic = lambda_in
  end subroutine set_henon_heiles_lambda_adiabatic

  ! ============================================================================
  ! CONSTRUCTOR
  ! ============================================================================
  function create_calculator(enabled, verbose, parallel) result(calc)
    logical, intent(in), optional :: enabled, verbose, parallel
    type(adiabatic_calculator) :: calc
    
    if (present(enabled)) calc%enabled = enabled
    if (present(verbose)) calc%verbose = verbose
    if (present(parallel)) calc%parallel = parallel
    
    calc%nstate = 1
    
    if (calc%verbose .and. calc%enabled) then
      print '(a)', "Adiabatic calculator created (enabled) for HENON-HEILES"
      print '(a,f8.4)', "  Lambda: ", lambda_henon_adiabatic
      if (calc%parallel) then
        print '(a)', "  Parallel execution: enabled"
      end if
    end if
  end function create_calculator

  ! Alias for the main program
  function create_adiabatic_calculator(enabled, verbose, parallel) result(calc)
    logical, intent(in), optional :: enabled, verbose, parallel
    type(adiabatic_calculator) :: calc
    
    calc = create_calculator(enabled, verbose, parallel)
  end function create_adiabatic_calculator

  ! ============================================================================
  ! SET LAMBDA
  ! ============================================================================
  subroutine set_lambda(this, lambda_in)
    class(adiabatic_calculator), intent(inout) :: this
    real(dp), intent(in) :: lambda_in
    
    lambda_henon_adiabatic = lambda_in
    if (this%verbose) then
      print '(a,es12.4)', "Adiabatic calculator lambda set to: ", lambda_in
    end if
  end subroutine set_lambda

  ! ============================================================================
  ! SET OUTPUT DIRECTORY
  ! ============================================================================
  subroutine set_output_dir(this, dirname)
    class(adiabatic_calculator), intent(inout) :: this
    character(len=*), intent(in) :: dirname
    
    this%output_dir = trim(dirname)
    if (this%verbose) then
      print '(a,a)', "Adiabatic output directory set to: ", trim(dirname)
    end if
  end subroutine set_output_dir

  ! ============================================================================
  ! INITIALIZE ADIABATIC CALCULATOR
  ! ============================================================================
  subroutine init_adiabatic(this, nstate_in, nnprod_in, tstep_in, filename)
    class(adiabatic_calculator), intent(inout) :: this
    integer(ip), intent(in) :: nstate_in, nnprod_in, tstep_in
    character(len=*), intent(in), optional :: filename
    
    integer(ip) :: i
    character(len=200) :: dir_command
    character(len=200) :: filepath
    
    if (.not. this%enabled) return
    
    this%nstate = 1
    this%nnprod = nnprod_in
    this%tstep = tstep_in
    this%current_step = 0
    
    if (this%verbose) then
      print '(a)', "Initializing adiabatic calculator for HENON-HEILES..."
      print '(a,i0)', "  Number of states: ", this%nstate
      print '(a,i0)', "  Grid points: ", this%nnprod
      print '(a,i0)', "  Time steps: ", this%tstep
    end if
    
    ! Create output directory
    dir_command = "mkdir -p " // trim(this%output_dir)
    call system(dir_command)
    
    ! Allocate storage
    allocate(this%potential_energy(this%nstate, this%nnprod))
    allocate(this%harmonic_energy(this%nstate, this%nnprod))
    allocate(this%anharmonic_energy(this%nstate, this%nnprod))
    if (this%store_potential_data) then
      allocate(this%potential_energy_time(this%nstate, this%tstep))
      allocate(this%times(this%tstep))
    end if
    
    ! Initialize
    this%potential_energy = 0.0_dp
    this%harmonic_energy = 0.0_dp
    this%anharmonic_energy = 0.0_dp
    this%potential_energy_time = 0.0_dp
    this%times = 0.0_dp
    
    ! Open output files
    if (present(filename)) then
      filepath = trim(this%output_dir)//trim(filename)
    else
      filepath = trim(this%output_dir)//"henon_heiles_potential_energy.dat"
    end if
    
    open(unit=this%file_unit_potential, file=filepath, status='replace')
    write(this%file_unit_potential, '(a)') '# Henon-Heiles Potential Energy Analysis'
    write(this%file_unit_potential, '(a)') '# GridPoint, Potential_Energy'
    flush(this%file_unit_potential)
    
    ! Open components file
    filepath = trim(this%output_dir)//"henon_heiles_potential_components.dat"
    open(unit=this%file_unit_components, file=filepath, status='replace')
    write(this%file_unit_components, '(a)') '# Henon-Heiles Potential Energy Components'
    write(this%file_unit_components, '(a)') '# GridPoint, Harmonic, Anharmonic, Ratio'
    flush(this%file_unit_components)
    
    ! Open statistics file
    filepath = trim(this%output_dir)//"henon_heiles_potential_stats.dat"
    open(unit=this%file_unit_stats, file=filepath, status='replace')
    write(this%file_unit_stats, '(a)') '# Henon-Heiles Potential Energy Statistics'
    write(this%file_unit_stats, '(a)') '# Time, Min, Max, Mean, StdDev'
    flush(this%file_unit_stats)
    
    if (this%verbose) then
      print '(a)', "Adiabatic calculator initialized successfully."
      print '(a,a)', "  Output directory: ", trim(this%output_dir)
    end if
  end subroutine init_adiabatic

  ! ============================================================================
  ! HENON-HEILES POTENTIAL EVALUATION
  ! ============================================================================
  function henon_heiles_potential_value(q, nmode, lambda_in) result(v)
    real(dp), intent(in) :: q(:)
    integer(ip), intent(in) :: nmode
    real(dp), intent(in) :: lambda_in
    real(dp) :: v
    
    integer :: m
    
    v = 0.0_dp
    
    ! Harmonic part: 1/2 * Σ q_m²
    do m = 1, nmode
      v = v + 0.5_dp * q(m)**2
    end do
    
    ! Anharmonic coupling: λ * Σ (q_m² * q_{m+1} - 1/3 * q_{m+1}³)
    do m = 1, nmode - 1
      v = v + lambda_in * (q(m)**2 * q(m+1) - (1.0_dp/3.0_dp) * q(m+1)**3)
    end do
    
  end function henon_heiles_potential_value

  ! ============================================================================
  ! COMPUTE TRANSFORMATION (IDENTITY FOR SINGLE STATE)
  ! ============================================================================
  subroutine compute_transformation(this, potential_matrices, nnprod, nstate)
    class(adiabatic_calculator), intent(inout) :: this
    real(dp), intent(in) :: potential_matrices(:,:,:)
    integer(ip), intent(in) :: nnprod, nstate
    
    integer(ip) :: i, j
    real(dp) :: v, v_harmonic, v_anharmonic, ratio
    real(dp) :: start_time, end_time
    
    if (.not. this%enabled) return
    
    if (nstate /= 1 .or. nnprod /= this%nnprod) then
      if (this%verbose) then
        print '(a)', "WARNING: Dimension mismatch in compute_transformation"
        print '(a,i0,a,i0)', "  Expected nnprod=", this%nnprod, " got ", nnprod
      end if
      return
    end if
    
    call cpu_time(start_time)
    
    if (this%verbose) then
      print '(a,i0,a)', "Analyzing Henon-Heiles potential for ", nnprod, " grid points"
    end if
    
    ! For single state, transformation is identity
    ! Store potential energy decomposition
    this%min_potential = huge(0.0_dp)
    this%max_potential = -huge(0.0_dp)
    this%mean_potential = 0.0_dp
    
    do i = 1, nnprod
      v = potential_matrices(1, 1, i)
      this%potential_energy(1, i) = v
      
      ! Approximate decomposition (for analysis)
      ! In a real implementation, we'd compute harmonic and anharmonic separately
      if (abs(v) > SMALL) then
        ! Use the coordinates if available, but for now approximate
        v_harmonic = v * 0.6_dp  ! Approximate harmonic fraction
        v_anharmonic = v * 0.4_dp
      else
        v_harmonic = 0.0_dp
        v_anharmonic = 0.0_dp
      end if
      
      this%harmonic_energy(1, i) = v_harmonic
      this%anharmonic_energy(1, i) = v_anharmonic
      
      ! Update statistics
      this%min_potential = min(this%min_potential, v)
      this%max_potential = max(this%max_potential, v)
      this%mean_potential = this%mean_potential + v
      
      ! Write to files
      write(this%file_unit_potential, '(i12,f16.8)') i, v
      
      if (abs(v) > SMALL) then
        ratio = v_anharmonic / v
      else
        ratio = 0.0_dp
      end if
      write(this%file_unit_components, '(i12,3f16.8)') i, v_harmonic, v_anharmonic, ratio
    end do
    
    this%mean_potential = this%mean_potential / real(nnprod, dp)
    this%std_potential = 0.0_dp
    do i = 1, nnprod
      this%std_potential = this%std_potential + &
           (this%potential_energy(1, i) - this%mean_potential)**2
    end do
    this%std_potential = sqrt(this%std_potential / real(nnprod, dp))
    
    flush(this%file_unit_potential)
    flush(this%file_unit_components)
    
    call cpu_time(end_time)
    this%compute_time = end_time - start_time
    
    if (this%verbose) then
      print '(a,f10.3,a)', "  Computation time: ", this%compute_time, " seconds"
      print '(a)', "Potential energy analysis completed."
      print '(a,es12.4)', "  Min potential: ", this%min_potential
      print '(a,es12.4)', "  Max potential: ", this%max_potential
      print '(a,es12.4)', "  Mean potential: ", this%mean_potential
      print '(a,es12.4)', "  Std deviation: ", this%std_potential
    end if
  end subroutine compute_transformation

  ! ============================================================================
  ! ANALYZE POTENTIAL ENERGY
  ! ============================================================================
  subroutine analyze_potential_energy(this, potential_matrices, nnprod, nstate)
    class(adiabatic_calculator), intent(inout) :: this
    real(dp), intent(in) :: potential_matrices(:,:,:)
    integer(ip), intent(in) :: nnprod, nstate
    
    call this%compute_transformation(potential_matrices, nnprod, nstate)
  end subroutine analyze_potential_energy

  ! ============================================================================
  ! TRANSFORM WAVEFUNCTION (TRIVIAL FOR SINGLE STATE)
  ! ============================================================================
  subroutine transform_wavefunction(this, diabatic_wf, nnprod, nstate, &
                                   time, step, store_probability)
    class(adiabatic_calculator), intent(inout) :: this
    complex(dp), intent(in) :: diabatic_wf(:,:)
    integer(ip), intent(in) :: nnprod, nstate
    real(dp), intent(in) :: time
    integer(ip), intent(in) :: step
    logical, intent(in), optional :: store_probability
    
    integer(ip) :: i
    real(dp) :: total_prob
    logical :: store
    
    if (.not. this%enabled) return
    
    if (nstate /= 1 .or. nnprod /= this%nnprod) then
      if (this%verbose) then
        print '(a)', "WARNING: Dimension mismatch in transform_wavefunction"
      end if
      return
    end if
    
    store = .true.
    if (present(store_probability)) store = store_probability
    
    ! For single state, adiabatic = diabatic
    ! Store the potential energy at this time
    if (store .and. step <= size(this%potential_energy_time, 2)) then
      ! Compute average potential energy at this time
      this%potential_energy_time(1, step) = 0.0_dp
      do i = 1, nnprod
        this%potential_energy_time(1, step) = this%potential_energy_time(1, step) + &
             abs(diabatic_wf(1, i))**2 * this%potential_energy(1, i)
      end do
      this%times(step) = time
      this%current_step = step
    end if
    
    ! Write statistics
    if (mod(step, 10) == 0) then
      total_prob = 0.0_dp
      do i = 1, nnprod
        total_prob = total_prob + abs(diabatic_wf(1, i))**2
      end do
      
      write(this%file_unit_stats, '(f12.6,4es16.8)') &
           time, this%min_potential, this%max_potential, &
           this%mean_potential, this%std_potential
      flush(this%file_unit_stats)
    end if
    
    if (this%verbose .and. mod(step, 100) == 0) then
      print '(a,f8.3,a)', "  Henon-Heiles potential analyzed at t=", time
    end if
    
  end subroutine transform_wavefunction

  ! ============================================================================
  ! COMPUTE ADIABATIC POPULATIONS (TRIVIAL FOR SINGLE STATE)
  ! ============================================================================
  subroutine compute_adiabatic_populations(this, diabatic_wf, nnprod, nstate, &
                                         time, step)
    class(adiabatic_calculator), intent(inout) :: this
    complex(dp), intent(in) :: diabatic_wf(:,:)
    integer(ip), intent(in) :: nnprod, nstate
    real(dp), intent(in) :: time
    integer(ip), intent(in) :: step
    
    call this%transform_wavefunction(diabatic_wf, nnprod, nstate, time, step, .true.)
    
  end subroutine compute_adiabatic_populations

  ! ============================================================================
  ! WRITE POTENTIAL DATA
  ! ============================================================================
  subroutine write_potential_data(this, times, filename)
    class(adiabatic_calculator), intent(in) :: this
    real(dp), intent(in) :: times(:)
    character(len=*), intent(in), optional :: filename
    
    integer :: i, nsteps
    character(len=200) :: filepath
    integer :: unit_out
    
    if (.not. this%enabled) return
    
    nsteps = min(size(times), size(this%potential_energy_time, 2))
    
    if (nsteps <= 0) return
    
    if (present(filename)) then
      filepath = trim(this%output_dir)//trim(filename)
    else
      filepath = trim(this%output_dir)//"henon_heiles_potential_time.dat"
    end if
    
    open(newunit=unit_out, file=filepath, status='replace')
    
    write(unit_out, '(a)') '# Henon-Heiles Potential Energy vs Time'
    write(unit_out, '(a)') '# Time, Potential_Energy'
    
    do i = 1, nsteps
      write(unit_out, '(f16.10,es16.8)') times(i), this%potential_energy_time(1, i)
    end do
    
    close(unit_out)
    
    if (this%verbose) then
      print '(a)', "Henon-Heiles potential energy data written."
    end if
  end subroutine write_potential_data

  ! ============================================================================
  ! WRITE POTENTIAL COMPONENTS
  ! ============================================================================
  subroutine write_potential_components(this)
    class(adiabatic_calculator), intent(in) :: this
    
    integer(ip) :: i
    
    if (.not. this%enabled) return
    
    ! Components already written during compute_transformation
    flush(this%file_unit_components)
    
    if (this%verbose) then
      print '(a)', "Henon-Heiles potential components written."
    end if
  end subroutine write_potential_components

  ! ============================================================================
  ! GET POTENTIAL ENERGY
  ! ============================================================================
  function get_potential_energy(this) result(potential)
    class(adiabatic_calculator), intent(in) :: this
    real(dp), allocatable :: potential(:,:)
    
    if (allocated(this%potential_energy)) then
      allocate(potential(size(this%potential_energy,1), &
                        size(this%potential_energy,2)))
      potential = this%potential_energy
    end if
  end function get_potential_energy

  ! ============================================================================
  ! GET POTENTIAL STATISTICS
  ! ============================================================================
  function get_potential_statistics(this) result(stats)
    class(adiabatic_calculator), intent(in) :: this
    real(dp) :: stats(4)  ! min, max, mean, std
    
    stats(1) = this%min_potential
    stats(2) = this%max_potential
    stats(3) = this%mean_potential
    stats(4) = this%std_potential
  end function get_potential_statistics

  ! ============================================================================
  ! CLEANUP
  ! ============================================================================
  subroutine cleanup_adiabatic(this)
    class(adiabatic_calculator), intent(inout) :: this
    
    if (allocated(this%potential_energy)) deallocate(this%potential_energy)
    if (allocated(this%harmonic_energy)) deallocate(this%harmonic_energy)
    if (allocated(this%anharmonic_energy)) deallocate(this%anharmonic_energy)
    if (allocated(this%potential_energy_time)) deallocate(this%potential_energy_time)
    if (allocated(this%times)) deallocate(this%times)
    
    if (this%file_unit_potential > 0) close(this%file_unit_potential)
    if (this%file_unit_components > 0) close(this%file_unit_components)
    if (this%file_unit_stats > 0) close(this%file_unit_stats)
    
    this%file_unit_potential = 400
    this%file_unit_components = 401
    this%file_unit_stats = 402
    
    if (this%verbose .and. this%enabled) then
      print '(a)', "Henon-Heiles adiabatic calculator cleaned up."
      if (this%compute_time > 0.0_dp) then
        print '(a,f10.3,a)', "  Total computation time: ", this%compute_time, " seconds"
      end if
    end if
  end subroutine cleanup_adiabatic

  ! ============================================================================
  ! GETTERS AND SETTERS
  ! ============================================================================
  function is_enabled(this) result(enabled)
    class(adiabatic_calculator), intent(in) :: this
    logical :: enabled
    enabled = this%enabled
  end function is_enabled
  
  subroutine enable(this)
    class(adiabatic_calculator), intent(inout) :: this
    this%enabled = .true.
    if (this%verbose) print '(a)', "Henon-Heiles adiabatic calculator enabled."
  end subroutine enable
  
  subroutine disable(this)
    class(adiabatic_calculator), intent(inout) :: this
    this%enabled = .false.
    if (this%verbose) print '(a)', "Henon-Heiles adiabatic calculator disabled."
  end subroutine disable

end module adiabatic_module