! ============================================================
! POTENTIAL_MODULE.F90 - HENON-HEILES SYSTEM
! Based on: J. Chem. Phys. 117, 10499 (2002)
! Benchmark calculations on high-dimensional Henon-Heiles 
! potentials with the MCTDH method
! ============================================================
!
! Henon-Heiles Potential:
! V(q) = 1/2 * Σ q_κ² + λ * Σ (q_κ² * q_{κ+1} - 1/3 * q_{κ+1}³)
!
! Parameters:
!   λ = 0.111803398875 (1/√80) - Standard value for benchmarks
!   Dimensionality: f = 4, 6, 10, 14, 18, 32
!   Units: Reduced units (ℏ = 1, m = 1, ω = 1)
! ============================================================

module potential_module
  use, intrinsic :: iso_fortran_env, only: real64, int32
  implicit none
  private
  
  ! Public subroutines
  public :: POTENTIAL, potential_
  public :: set_lambda, get_lambda
  public :: henon_heiles_potential   ! Fixed: removed extra 'n'
  public :: enable_debug, disable_debug, print_potential_info
  
  ! Constants
  real(real64), parameter :: PI = 3.14159265358979323846d0
  real(real64), parameter :: DEFAULT_LAMBDA = 0.111803398875d0  ! 1/√80
  
  ! Module variables
  real(real64), private :: lambda = DEFAULT_LAMBDA
  integer, private :: current_nmode = 0
  
  ! Diagnostic variables
  logical, private :: debug_mode = .false.
  integer, private :: call_count = 0

contains

! ============================================================
! SUBROUTINE: SET_LAMBDA
! ============================================================
subroutine set_lambda(lambda_in)
  real(real64), intent(in) :: lambda_in
  lambda = lambda_in
  if (debug_mode) then
    print '(a,es12.4)', "Henon-Heiles: lambda set to ", lambda
  end if
end subroutine set_lambda

! ============================================================
! FUNCTION: GET_LAMBDA
! ============================================================
function get_lambda() result(lambda_out)
  real(real64) :: lambda_out
  lambda_out = lambda
end function get_lambda

! ============================================================
! SUBROUTINE: POTENTIAL - MAIN INTERFACE
! ============================================================
subroutine POTENTIAL(grid, v_potential, nn, nmode, nstate, nnprod, freqn, ffn)
  
  implicit none
  
  ! Input parameters
  integer(int32), intent(in) :: nn, nmode, nstate, nnprod
  real(real64), intent(in) :: grid(nn, nmode)
  real(real64), intent(in) :: freqn(nmode), ffn(nmode)
  
  ! Output potential matrix
  real(real64), intent(out) :: v_potential(nstate, nstate, nnprod)
  
  ! Local variables
  integer :: point, m
  real(real64) :: q_m, q_next, v_local
  integer, dimension(:,:), allocatable :: tot
  
  ! Store current nmode
  current_nmode = nmode
  call_count = call_count + 1
  
  ! Debug output
  if (debug_mode .and. mod(call_count, 10) == 0) then
    print '(a,i6,a,i3,a)', "Henon-Heiles POTENTIAL called ", call_count, &
                          " times for f=", nmode, " dimensions"
  end if
  
  ! Allocate and compute index mapping
  allocate(tot(nnprod, nmode))
  call packindex_local(tot, nn, nmode, nnprod)
  
  ! Check that nstate is 1 for Henon-Heiles
  if (nstate /= 1) then
    if (debug_mode) then
      print '(a,i0,a)', "WARNING: Henon-Heiles potential called with nstate=", nstate, &
                       " but should be 1. Only first state will be computed."
    end if
  end if
  
  ! Initialize potential matrix
  v_potential = 0.0d0
  
  !$omp parallel do private(point, m, q_m, q_next, v_local) &
  !$omp if(nnprod > 1000) schedule(dynamic)
  do point = 1, nnprod
    
    v_local = 0.0d0
    
    ! ============================================================
    ! HARMONIC PART: 1/2 * Σ q_κ²
    ! ============================================================
    do m = 1, nmode
      q_m = grid(tot(point,m), m)
      v_local = v_local + 0.5d0 * q_m**2
    end do
    
    ! ============================================================
    ! ANHARMONIC COUPLING: λ * Σ (q_κ² * q_{κ+1} - 1/3 * q_{κ+1}³)
    ! ============================================================
    do m = 1, nmode - 1
      q_m = grid(tot(point,m), m)
      q_next = grid(tot(point,m+1), m+1)
      v_local = v_local + lambda * (q_m**2 * q_next - (1.0d0/3.0d0) * q_next**3)
    end do
    
    ! Store potential (only first state)
    v_potential(1,1,point) = v_local
    
  end do
  !$omp end parallel do
  
  deallocate(tot)
  
end subroutine POTENTIAL

! ============================================================
! SUBROUTINE: POTENTIAL_ - COMPATIBILITY INTERFACE
! ============================================================
subroutine potential_(grid, v_potential, nn, nmode, nstate, nnprod, freqn, ffn)
  implicit none
  integer(int32), intent(in) :: nn, nmode, nstate, nnprod
  real(real64), intent(in) :: grid(nn, nmode)
  real(real64), intent(in) :: freqn(nmode), ffn(nmode)
  real(real64), intent(out) :: v_potential(nstate, nstate, nnprod)
  
  call POTENTIAL(grid, v_potential, nn, nmode, nstate, nnprod, freqn, ffn)
end subroutine potential_

! ============================================================
! SUBROUTINE: HENON_HEILES_POTENTIAL - DIRECT EVALUATION
! ============================================================
subroutine henon_heiles_potential(grid, v_potential, nn, nmode, nstate, nnprod, lambda_in)
  implicit none
  integer(int32), intent(in) :: nn, nmode, nstate, nnprod
  real(real64), intent(in) :: grid(nn, nmode)
  real(real64), intent(in) :: lambda_in
  real(real64), intent(out) :: v_potential(nstate, nstate, nnprod)
  
  integer :: point, m
  real(real64) :: q_m, q_next, v_local
  integer, dimension(:,:), allocatable :: tot
  
  ! Allocate and compute index mapping
  allocate(tot(nnprod, nmode))
  call packindex_local(tot, nn, nmode, nnprod)
  
  ! Initialize
  v_potential = 0.0d0
  
  !$omp parallel do private(point, m, q_m, q_next, v_local) &
  !$omp if(nnprod > 1000) schedule(dynamic)
  do point = 1, nnprod
    
    v_local = 0.0d0
    
    ! Harmonic part
    do m = 1, nmode
      q_m = grid(tot(point,m), m)
      v_local = v_local + 0.5d0 * q_m**2
    end do
    
    ! Anharmonic coupling
    do m = 1, nmode - 1
      q_m = grid(tot(point,m), m)
      q_next = grid(tot(point,m+1), m+1)
      v_local = v_local + lambda_in * (q_m**2 * q_next - (1.0d0/3.0d0) * q_next**3)
    end do
    
    v_potential(1,1,point) = v_local
    
  end do
  !$omp end parallel do
  
  deallocate(tot)
  
end subroutine henon_heiles_potential

! ============================================================
! FUNCTION: POTENTIAL_VALUE - SINGLE POINT EVALUATION
! ============================================================
function potential_value(q, nmode) result(v)
  implicit none
  real(real64), intent(in) :: q(:)
  integer, intent(in) :: nmode
  real(real64) :: v
  
  integer :: m
  
  v = 0.0d0
  
  ! Harmonic part
  do m = 1, nmode
    v = v + 0.5d0 * q(m)**2
  end do
  
  ! Anharmonic part
  do m = 1, nmode - 1
    v = v + lambda * (q(m)**2 * q(m+1) - (1.0d0/3.0d0) * q(m+1)**3)
  end do
  
end function potential_value

! ============================================================
! FUNCTION: POTENTIAL_VALUE_LAMBDA - WITH CUSTOM LAMBDA
! ============================================================
function potential_value_lambda(q, nmode, lambda_in) result(v)
  implicit none
  real(real64), intent(in) :: q(:)
  integer, intent(in) :: nmode
  real(real64), intent(in) :: lambda_in
  real(real64) :: v
  
  integer :: m
  
  v = 0.0d0
  
  ! Harmonic part
  do m = 1, nmode
    v = v + 0.5d0 * q(m)**2
  end do
  
  ! Anharmonic part
  do m = 1, nmode - 1
    v = v + lambda_in * (q(m)**2 * q(m+1) - (1.0d0/3.0d0) * q(m+1)**3)
  end do
  
end function potential_value_lambda

! ============================================================
! SUBROUTINE: COMPUTE_FORCES
! ============================================================
subroutine compute_forces(q, force, nmode, lambda_in)
  implicit none
  real(real64), intent(in) :: q(:)
  real(real64), intent(out) :: force(:)
  integer, intent(in) :: nmode
  real(real64), intent(in) :: lambda_in
  
  integer :: m
  
  ! F_m = -∂V/∂q_m
  do m = 1, nmode
    force(m) = -q(m)  ! Harmonic part
    
    ! Anharmonic contributions
    if (m > 1) then
      ! From term (q_{m-1}² * q_m - 1/3 * q_m³)
      force(m) = force(m) - lambda_in * (q(m-1)**2 - q(m)**2)
    end if
    
    if (m < nmode) then
      ! From term (q_m² * q_{m+1} - 1/3 * q_{m+1}³)
      force(m) = force(m) - lambda_in * 2.0d0 * q(m) * q(m+1)
    end if
  end do
  
end subroutine compute_forces

! ============================================================
! SUBROUTINE: PACKINDEX_LOCAL
! ============================================================
subroutine packindex_local(tot, nn, nmode, nnprod)
  implicit none
  integer(int32), intent(in) :: nn, nmode, nnprod
  integer, dimension(nnprod, nmode), intent(out) :: tot
  
  integer :: i, j, prod
  integer, allocatable :: indices(:)
  
  allocate(indices(nmode))
  
  do i = 1, nnprod
    prod = i - 1
    do j = 1, nmode
      indices(j) = mod(prod, nn) + 1
      prod = prod / nn
    end do
    
    do j = 1, nmode
      tot(i,j) = indices(j)
    end do
  end do
  
  deallocate(indices)
end subroutine packindex_local

! ============================================================
! SUBROUTINE: ENABLE_DEBUG
! ============================================================
subroutine enable_debug()
  debug_mode = .true.
  print '(a)', "Henon-Heiles potential module: Debug mode ENABLED"
end subroutine enable_debug

! ============================================================
! SUBROUTINE: DISABLE_DEBUG
! ============================================================
subroutine disable_debug()
  debug_mode = .false.
  print '(a)', "Henon-Heiles potential module: Debug mode DISABLED"
end subroutine disable_debug

! ============================================================
! FUNCTION: GET_POTENTIAL_DIMENSIONS
! ============================================================
function get_current_nmode() result(n)
  integer :: n
  n = current_nmode
end function get_current_nmode

! ============================================================
! SUBROUTINE: POTENTIAL_GRADIENT - FOR CLASSICAL PROPAGATION
! ============================================================
subroutine potential_gradient(q, grad, nmode, lambda_in)
  implicit none
  real(real64), intent(in) :: q(:)
  real(real64), intent(out) :: grad(:)
  integer, intent(in) :: nmode
  real(real64), intent(in) :: lambda_in
  
  integer :: m
  
  ! ∂V/∂q_m
  do m = 1, nmode
    grad(m) = q(m)  ! Harmonic part
    
    ! Anharmonic contributions
    if (m > 1) then
      ! From term (q_{m-1}² * q_m - 1/3 * q_m³)
      grad(m) = grad(m) + lambda_in * (q(m-1)**2 - q(m)**2)
    end if
    
    if (m < nmode) then
      ! From term (q_m² * q_{m+1} - 1/3 * q_{m+1}³)
      grad(m) = grad(m) + lambda_in * 2.0d0 * q(m) * q(m+1)
    end if
  end do
  
end subroutine potential_gradient

! ============================================================
! FUNCTION: POTENTIAL_HESSIAN - FOR SECOND DERIVATIVES
! ============================================================
function potential_hessian(q, nmode, lambda_in) result(hess)
  implicit none
  real(real64), intent(in) :: q(:)
  integer, intent(in) :: nmode
  real(real64), intent(in) :: lambda_in
  real(real64) :: hess(nmode, nmode)
  
  integer :: m
  
  ! Initialize Hessian
  hess = 0.0d0
  
  ! Diagonal elements: ∂²V/∂q_m²
  do m = 1, nmode
    hess(m,m) = 1.0d0  ! Harmonic part
    
    ! Anharmonic contributions
    if (m > 1) then
      hess(m,m) = hess(m,m) - 2.0d0 * lambda_in * q(m)
    end if
    
    if (m < nmode) then
      hess(m,m) = hess(m,m) + 2.0d0 * lambda_in * q(m+1)
    end if
  end do
  
  ! Off-diagonal elements: ∂²V/∂q_m∂q_{m+1}
  do m = 1, nmode - 1
    hess(m,m+1) = 2.0d0 * lambda_in * q(m)
    hess(m+1,m) = hess(m,m+1)
  end do
  
end function potential_hessian

! ============================================================
! FUNCTION: ZERO_POINT_ENERGY - FOR f-DIMENSIONAL SYSTEM
! ============================================================
function zero_point_energy(nmode) result(e_zp)
  implicit none
  integer, intent(in) :: nmode
  real(real64) :: e_zp
  
  ! In reduced units with ℏ=1, ω=1
  ! E_zp = Σ (1/2 * ℏ * ω) = nmode/2
  e_zp = 0.5d0 * nmode
  
end function zero_point_energy

! ============================================================
! SUBROUTINE: PRINT_POTENTIAL_INFO
! ============================================================
subroutine print_potential_info()
  print '(a)', ""
  print '(a)', "Henon-Heiles Potential Module Information"
  print '(a)', "========================================"
  print '(a,es12.4)', "  Lambda (anharmonicity): ", lambda
  print '(a,es12.4)', "  Default Lambda (1/√80): ", DEFAULT_LAMBDA
  print '(a,es12.4)', "  Zero point energy: ", zero_point_energy(current_nmode)
  print '(a,l1)', "  Debug mode: ", debug_mode
  print '(a,i0)', "  Call count: ", call_count
  print '(a)', "========================================"
  print '(a)', ""
end subroutine print_potential_info

end module potential_module