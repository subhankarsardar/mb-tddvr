# MB-TDDVR User Guide

**Multi-Basis Time-Dependent Discrete Variable Representation**
**Version 1.0.0**

---

## Table of Contents

1. [Introduction](#1-introduction)
2. [Installation](#2-installation)
3. [Basic Workflow](#3-basic-workflow)
4. [Configuration](#4-configuration)
5. [Running Calculations](#5-running-calculations)
6. [Understanding the Output](#6-understanding-the-output)
7. [Basis Selection Strategy](#7-basis-selection-strategy)
8. [Propagation Schemes](#8-propagation-schemes)
9. [Adaptive Time-Stepping](#9-adaptive-time-stepping)
10. [Analysis Modules](#10-analysis-modules)
11. [Parallel Execution](#11-parallel-execution)
12. [Troubleshooting](#12-troubleshooting)
13. [Examples](#13-examples)
14. [Advanced Usage](#14-advanced-usage)
15. [Performance Tuning](#15-performance-tuning)
16. [Frequently Asked Questions](#16-frequently-asked-questions)
17. [Getting Help](#17-getting-help)
18. [Appendix A — File Format Reference](#appendix-a--file-format-reference)
19. [Appendix B — Basis Function Definitions](#appendix-b--basis-function-definitions)
20. [Appendix C — Propagation Scheme Details](#appendix-c--propagation-scheme-details)

---

## 1. Introduction

MB-TDDVR (Multi-Basis Time-Dependent Discrete Variable Representation)
is a Fortran 2008+ framework for high-dimensional quantum dynamics
simulations of vibronically coupled molecular systems.

### 1.1 What MB-TDDVR Does

- Propagates nuclear wavepackets on coupled potential energy surfaces
- Uses coordinate-dependent DVR basis functions (Hermite, Legendre, sine)
- Supports multiple propagation schemes (SO-2, SO-4, Magnus, RK4, adaptive)
- Provides adaptive time-stepping with automatic error control
- Parallelizes via OpenMP shared-memory
- Outputs spectra, populations, energies, and reduced densities

### 1.2 What MB-TDDVR Does Not Do

- It does not perform electronic structure calculations. You must supply
  potential energy surfaces and coupling parameters from an external
  quantum chemistry calculation or from a model Hamiltonian.
- It does not currently support MPI distributed-memory parallelism.
- It is not a general-purpose quantum chemistry package.

### 1.3 Target Users

- Theoretical chemists studying nonadiabatic dynamics
- Physical chemists investigating vibronic coupling
- Computational scientists developing quantum dynamics methods

---

## 2. Installation

### 2.1 System Requirements

| Component | Minimum | Recommended |
|---|---|---|
| Operating System | Linux (Ubuntu 20.04+, CentOS 7+) | Ubuntu 22.04 |
| Compiler | gfortran ≥ 9.0 | gfortran 11+ or ifort 2021+ |
| Memory | 4 GB | 8 GB or more |
| Disk | 500 MB | 2 GB |
| BLAS/LAPACK | Reference | OpenBLAS or MKL |

### 2.2 Clone the Repository

```bash
git clone https://github.com/subhankarsardar/mb-tddvr.git
cd mb-tddvr